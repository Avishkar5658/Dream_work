<?php
include "db.php"; // tuzha database connection

$first_name = "Admin";
$last_name = "Trail";
$email = "admin@example.com";
$password = password_hash("Admin@123", PASSWORD_DEFAULT);
$role = "admin";

$stmt = $conn->prepare("INSERT INTO users (first_name,last_name,email,password,role) VALUES (?,?,?,?,?)");
$stmt->bind_param("sssss",$first_name,$last_name,$email,$password,$role);
$stmt->execute();
$stmt->close();

echo "Admin added successfully!";
?>
